class Point
  attr_accessor :x,:y
  def initialize(a,b)
    @x=a
    @y=b
  end
end

