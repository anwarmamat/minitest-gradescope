#!/usr/bin/env bash

ruby /autograder/source/src/public.rb --gradescope >/dev/null

cat results.json


