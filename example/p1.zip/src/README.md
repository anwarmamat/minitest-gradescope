This folder includes all the files except the solution. Autograder copies all the files
from this folder and student submission to the /autograder/source folder and executes
run_atuograder script.

This folder includes:

1. All the test files
2. All the necessary files that student do not have to submit
3. score.txt: This file includes all the test names and their score.
